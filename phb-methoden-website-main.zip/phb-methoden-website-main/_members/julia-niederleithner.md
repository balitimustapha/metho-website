---
name: Julia Niederleithner
image: images/portrait-julia-niederleithner.jpg
description: Tutorin
role: shk
aliases:
  - J Niederleithner
  - Julia Niederleithner
links:
  email: j.niederleithner@stud.phb.de
---

## Lehrveranstaltung: Tutorium Statistik 1

Das Tutorium findet während der Vorlesungszeit Donnerstags zwischen 12 bis 14 Uhr statt.

