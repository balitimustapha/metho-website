---
name: Sophia von Christen
image: images/portrait-sophia-von-christen.jpg
description: Tutorin
role: shk
aliases:
  - S von Christen
  - Sophia von Christen
links:
  email: s.vonchristen@stud.phb.de
---

## Lehrveranstaltung: Tutorium Statistik 1

Das Tutorium findem während der Vorlesungszeit Donnerstags zwischen 12 bis 14 Uhr statt. 

