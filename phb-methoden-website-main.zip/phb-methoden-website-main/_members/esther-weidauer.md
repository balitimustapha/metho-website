---
name: Esther Weidauer
image: images/portrait-esther-weidauer.jpg
description: Studentische Hilfskraft
role: shk
aliases:
  - E Weidauer
  - Esther Weidauer
links:
  home-page: https://www.aesthr.com
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
