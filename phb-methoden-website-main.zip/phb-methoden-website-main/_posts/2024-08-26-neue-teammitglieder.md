---
title: Neue Teammitglieder
image: images/photo.jpg
author: robert-miller
---

Die Arbeitsgruppe erhält in den kommenden Semester Unterstützung durch Julia Niederleithner und Sophia von Christen, welche die Tutorien Statistik 1 und 2 leiten werden. Außerdem freuen wir uns Ida Hawlitschek als Projektstudentin im [Team](/team/) begrüßen zu dürfen.
