---
title: Neue Webseite der Methodenlehre an der PHB
image: images/photo.jpg
author: esther-weidauer
---

Die Arbeitsgruppe für psychologische Methodenlehre ist nun auch mit eigener Website vertreten.

Hier werden [Teammitglieder](/team/), [aktuelle Forschungsprojekte](/forschung/) sowie Themen der [Lehre](/lehre/) wie z.B. Qualifikationsarbeiten vorgestellt.
