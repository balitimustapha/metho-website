
# PHB-MethodsDESCRIPTION=An engaging 1-3 sentence description of your lab.'s Website

Visit **[methodenlehre.phb.de](http://methodenlehre.phb.de)** 🚀

_Built with [Lab Website Template](https://greene-lab.gitbook.io/lab-website-template-docs)_
