def main(entry):
    """
    receives single list entry from sources data file
    returns list of sources to cite
    """
    return [entry]
