#!/usr/bin/env bash

set -xe

R --no-save --no-restore -f background-images.r
